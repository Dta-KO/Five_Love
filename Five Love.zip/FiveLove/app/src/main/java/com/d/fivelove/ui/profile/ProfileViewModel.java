package com.d.fivelove.ui.profile;

import android.util.Log;

import androidx.lifecycle.ViewModel;

import com.d.fivelove.model.User;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

public class ProfileViewModel extends ViewModel {
    // TODO: Implement the ViewModel

}