package com.d.fivelove.activities;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.net.sip.SipProfile;
import android.os.Bundle;
import android.widget.Chronometer;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;

import com.d.fivelove.databinding.ActivityCallAudioBinding;
import com.d.fivelove.utils.AudioCall;
import com.d.fivelove.utils.Constants;

public class CallAudioActivity extends FragmentActivity {
    private ActivityCallAudioBinding binding;
    private ImageButton btnCallEnd, btnVolume, btnAddFriend;
    private Chronometer timeCall;
    private TextView txtState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCallAudioBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        init();
        String partnerId = getIntent().getStringExtra(Constants.REMOTE_MSG_INVITER_ID);
        setBtnVolume();
        setBtnCallEnd();
        if (partnerId != null) {
            AudioCall.startCall(partnerId, CallAudioActivity.this, txtState, timeCall);
        }
        AudioCall.listenCall(CallAudioActivity.this, txtState, timeCall);
    }

    private void init() {
        btnAddFriend = binding.btnAddFriend;
        btnCallEnd = binding.btnCallEnd;
        btnVolume = binding.btnVolume;
        txtState = binding.txtState;
        timeCall = binding.timeCall;
    }

    private void setBtnCallEnd() {
        btnCallEnd.setOnClickListener(view -> {
            AudioCall.endCall(this);
            Intent intent = new Intent(CallAudioActivity.this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
        });
    }

    private void setBtnVolume() {
        Drawable drawableVolume = btnVolume.getDrawable();
        btnVolume.setOnClickListener(view -> {
            if (drawableVolume instanceof TransitionDrawable) {
                btnVolume.setImageDrawable(drawableVolume);
                ((TransitionDrawable) drawableVolume).setCrossFadeEnabled(true);
                ((TransitionDrawable) drawableVolume).reverseTransition(0);
            }
        });
    }

    @Override
    protected void onStop() {
        super.onStop();
        AudioCall.endCall(this);
    }
}