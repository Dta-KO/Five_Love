package com.d.fivelove.ui.chat;

import androidx.lifecycle.ViewModel;

public class ChatViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}