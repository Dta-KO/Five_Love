package com.d.fivelove;

import android.app.Application;

/**
 * Created by Nguyen Kim Khanh on 9/11/2020.
 */
public class FiveLoveApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

    }
}
