package com.d.fivelove.utils;

import android.app.Activity;
import android.content.Context;
import android.widget.Chronometer;
import android.widget.TextView;

/**
 * Created by Nguyen Kim Khanh on 9/11/2020.
 */
public class AudioCall {

    public static void initCall(Context context,String idCall) {


    }

    public static void startCall(String partnerId, Activity activity, TextView txtState, Chronometer timeCall) {

    }

    public static void listenCall(Activity activity, TextView txtState, Chronometer timeCall) {
    }

    public static void endCall(Activity activity) {

    }


}
